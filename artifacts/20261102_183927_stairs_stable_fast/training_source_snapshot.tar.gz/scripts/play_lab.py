#!/usr/bin/env python3
"""Evaluate or interactively view a checkpoint produced by this project."""
import argparse
import json
import time
from pathlib import Path
import _bootstrap
from go2_him.settings import load_settings


def main():
    from isaaclab.app import AppLauncher
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--num-envs", type=int, default=16)
    parser.add_argument("--steps", type=int, default=1500)
    parser.add_argument("--gait-metrics", action="store_true", help="Collect independent pre-step gait diagnostics")
    parser.add_argument("--episodes-per-env", type=int, default=0,
        help="Count at most this many episodes per environment and stop once all finish; 0 preserves unlimited counting")
    parser.add_argument("--output", type=Path, help="Evaluation JSON output path")
    parser.add_argument("--interactive", action="store_true",
        help="Keep the GUI open until closed, pace playback in real time, and skip evaluation output")
    parser.add_argument("--view", choices=("oblique", "front"), default="oblique",
        help="Interactive camera preset; front makes lateral foot spreading easier to inspect")
    parser.add_argument("--set", action="append", default=[])
    AppLauncher.add_app_launcher_args(parser)
    args = parser.parse_args()
    if args.interactive and args.headless:
        parser.error("--interactive requires a graphical session; omit --headless")
    if args.steps <= 0:
        parser.error("--steps must be positive")
    if args.episodes_per_env < 0:
        parser.error("--episodes-per-env must be non-negative")
    if not args.checkpoint.is_file(): parser.error("Checkpoint not found")
    run_dir = args.checkpoint.parent
    if not (run_dir / "manifest.json").is_file(): parser.error("Expected a checkpoint from this project")
    s = load_settings(run_dir / "settings.yaml", args.set + ["num_envs=" + str(args.num_envs)])
    app = AppLauncher(args).app
    env = None
    try:
        import torch
        from go2_him.lab_config import build_env_cfg, agent_config, FOOT_NAMES
        from go2_him.gait_metrics import EpisodeCounter, GaitMetrics
        from himloco_lab.envs import HimlocoManagerBasedRLEnv
        from himloco_lab.rsl_rl.wrappers.himloco_vec_env_wrapper import HimlocoVecEnvWrapper
        from himloco_lab.rsl_rl.runners.him_on_policy_runner import HIMOnPolicyRunner
        device = args.device or "cuda:0"
        torch.manual_seed(s["seed"])
        cfg = build_env_cfg(s, device, evaluation=True)
        if args.interactive:
            cfg.viewer.origin_type = "asset_root"
            cfg.viewer.asset_name = "robot"
            cfg.viewer.env_index = 0
            # Look down steeply enough that the ascending treads do not occlude
            # the robot when the camera is ahead of it on the staircase.
            cfg.viewer.eye = (2.2, 0.6, 2.2) if args.view == "front" else (2.5, 3.2, 2.0)
            cfg.viewer.lookat = (0.3, 0.0, 0.10) if args.view == "front" else (0.6, 0.0, 0.15)
        env = HimlocoManagerBasedRLEnv(cfg)
        wrapped = HimlocoVecEnvWrapper(env, history_length=5, clip_actions=s["control"]["action_clip"])
        runner = HIMOnPolicyRunner(wrapped, agent_config(s,device), log_dir=None, device=device)
        runner.load(str(args.checkpoint), load_optimizer=False)
        policy = runner.get_inference_policy(device=device)
        obs = wrapped.get_observations()
        counter = EpisodeCounter(env.num_envs, env.device, args.episodes_per_env)
        metrics = GaitMetrics(env, FOOT_NAMES, s["control"]["action_scale"], s["control"]["action_clip"]) if args.gait_metrics and not args.interactive else None
        previous_raw_actions = torch.zeros_like(env.action_manager.action)
        steps = 0
        print(f"GO2_PLAYBACK_READY checkpoint={args.checkpoint} interactive={args.interactive}", flush=True)
        with torch.inference_mode():
            while app.is_running() and (args.interactive or steps < args.steps):
                started = time.perf_counter()
                if metrics is not None:
                    metrics.update_pre_step(previous_raw_actions, counter.active)
                raw_actions = policy(obs)
                # Preserve actual policy output before the wrapper's clipping.
                previous_raw_actions = raw_actions.clone()
                obs, _, _, done, _, _, _ = wrapped.step(raw_actions)
                steps += 1
                if args.interactive:
                    time.sleep(max(0.0, env.step_dt - (time.perf_counter() - started)))
                    continue
                # v2.3.2 get_term returns the current step termination buffer, retained across reset.
                counter.update(done, env.termination_manager.get_term("success"), env.reset_time_outs, env.reset_terminated)
                if counter.all_finished():
                    break
        if args.interactive:
            return
        report = dict(steps=steps, max_steps=args.steps, **counter.report(), checkpoint=str(args.checkpoint), settings=s)
        report["stop_reason"] = "episode_target_reached" if counter.all_finished() else ("step_limit" if steps >= args.steps else "application_closed")
        if metrics is not None:
            report["gait_metrics"] = metrics.report()
            if args.episodes_per_env == 1:
                successful_metrics = metrics.report(counter.successes > 0)
                successful_metrics["selection"] = "completed_successful_first_episodes_only"
                report["gait_metrics_successful_episodes"] = successful_metrics
        output = args.output or run_dir / (args.checkpoint.stem + "_evaluation.json")
        output.parent.mkdir(parents=True, exist_ok=True)
        encoded = json.dumps(report, indent=2, allow_nan=False)
        output.write_text(encoded)
        print(encoded)
    finally:
        if env is not None: env.close()
        app.close()


if __name__ == "__main__": main()
